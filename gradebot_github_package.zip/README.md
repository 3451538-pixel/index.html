# GradeBot Pro

This is a self-contained chatbot for Moodle Gradebook help.

## Deploy on GitHub Pages
1. Create a new repository on GitHub (e.g., `gradebot`).
2. Upload these files (`index.html` and `README.md`).
3. Go to **Settings → Pages**.
4. Under *Branch*, select `main` and `/ (root)` folder.
5. Save — GitHub Pages will give you a live link like:

```
https://<your-username>.github.io/gradebot/
```

Then share the link with your team 🚀
